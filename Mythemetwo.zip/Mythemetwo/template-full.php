<?php
/* Template Name: Undersidan full */
get_header(); 
?>

<main>
			<section>
				<div class="container">
					<div class="row">
						<div>
                        <?php the_title( '<h1>', '</h1>' ); ?>
                        <?php
                            if ( have_posts() ){

                             while ( have_posts() ){

                           the_post();
                            get_template_part('template-parts/content', 'page' );
    }
}
?>
					
				</div>
			</section>
        </main>
        
<?php
get_footer();
?>