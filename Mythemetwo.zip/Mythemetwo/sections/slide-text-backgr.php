<div class="slide no-image" style="background-image: url('<?php the_sub_field("imagine_ex1"); ?>');">
					<div class="container">
						<div class="row">
							<div class="col-xs-12">
                            <?php the_sub_field("text_exe1"); ?>
							</div>
						</div>
					</div>
				</div>