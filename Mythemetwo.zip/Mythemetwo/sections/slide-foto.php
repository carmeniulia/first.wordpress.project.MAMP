<div class="slide" style="background-image: url('<?php the_sub_field("foto_one"); ?>');">
				</div>