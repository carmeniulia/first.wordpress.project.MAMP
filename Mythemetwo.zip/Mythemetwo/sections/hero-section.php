
<section class="hero" style= "background-image:url('<?php the_sub_field("image_hero_hem"); ?>') ">
  <div class="container">
	<div class="row">
	   <div class="col-xs-12 column">
		   <div class="text">
                 <h1 >  <?php the_sub_field("title_hero_hem"); ?></h1>
                 <p><?php the_sub_field("title_small_hero"); ?></p>
          </div>
	    </div>
	 </div> 
  </div>
</section> 