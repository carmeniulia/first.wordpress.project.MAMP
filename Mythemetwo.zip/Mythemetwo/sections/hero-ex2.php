<section class="hero small" style="background-image: url('<?php the_sub_field("image_ex2"); ?>">
				<div class="container">
					<div class="row">
						<div class="col-xs-12 column">
							<div class="text">
                                <h1><?php the_sub_field("title_ex2"); ?></h1>
							</div>
						</div>
					</div>
				</div>
			</section> 