<div class="slide" style="background-image: url('<?php the_sub_field("background_image"); ?>');">
					<div class="container">
						<div class="row">
							<div class="col-xs-12">
                            <?php the_sub_field("text_slide_tre"); ?>
							</div>
						</div>
					</div> 
				</div>