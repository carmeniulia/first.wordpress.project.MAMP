				<div class="slide red no-image">
					<div class="container">
						<div class="row">
							<div class="col-xs-6 text-center">
							    <?php the_sub_field('imagge_icon');  ?> 
							</div>
							<div class="col-xs-6">
							     <?php the_sub_field('text_s'); ?> 
							</div>
						</div>
					</div>
				</div>