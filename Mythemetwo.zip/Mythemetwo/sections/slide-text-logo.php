<div class="slide black no-image">
					<div class="container">
						<div class="row">
							<div class="col-xs-6">
                            <?php the_sub_field("text_black");  ?>
							</div>
							<div class="col-xs-6 text-center">
                            <?php the_sub_field("logo_black");  ?>
							</div>
						</div>
					</div>
                </div>
