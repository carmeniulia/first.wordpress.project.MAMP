				<div class="slide black no-image">
					<div class="container">
						<div class="row">
							<div class="col-xs-6">
							  <?php the_sub_field('text_f');  ?>
							</div>
							<div class="col-xs-6 text-center">
						      <img src="<?php the_sub_field('imagee'); ?>" >	
							</div>
						</div>
					</div>
				</div>

				