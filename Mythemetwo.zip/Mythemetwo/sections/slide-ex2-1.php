<div class="slide" style="background-image: url('<?php the_sub_field("bildslide"); ?>');">
</div>
