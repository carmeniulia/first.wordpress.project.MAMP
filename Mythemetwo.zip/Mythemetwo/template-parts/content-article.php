
<main>
	<section>
		<div class="container">
			<div class="row">
				<div id="primary" class="col-xs-12 col-md-9">
					<article>
					<?php
                    the_post_thumbnail('post-thumbnail', ['class' => 'img-responsive responsive--full', 'title' => 'Feature image']);
                    ?>
						<h1 class="title"><?php the_title(); ?></h1>
						<ul class="meta">
						<li>
						<i class="fa fa-calendar"></i> <?php the_date(); ?>
						</li>
						<li>
						<i class="fa fa-user"></i> <?php the_author(); ?>
							</li>
							<li>
								<i class="fa fa-tag"></i> <?php the_category( $separator = ' , ') ?>       
						</li>
                          </ul>
                                
          <p>
             <?php
               the_content();
             ?>

          </p>
          </article>
     </div>
			<aside id="secondary" class="col-xs-12 col-md-3">
				<div id="sidebar">
					<ul>
						<li>
							<form id="searchform" class="searchform">
								<div>
												<label class="screen-reader-text">Sök efter:</label>
												<input type="text" />
												<input type="submit" value="Sök" />
											</div>
										</form>
									</li>
								</ul>
								<ul role="navigation">
								
									<li>
										<h2>Arkiv</h2>
										<ul>
											<li>
												<?php  wp_get_archives(); ?> 
											</li>
										</ul>
									</li>
									<li class="categories">
										<h2>Kategorier</h2>
										<ul>
											<li class="cat-item">
										  <?php	the_category(); ?>
											</li>
											
										</ul>
									</li>
								</ul>
							</div>
						</aside>
					</div>
				</div>
			</section>
		</main>

