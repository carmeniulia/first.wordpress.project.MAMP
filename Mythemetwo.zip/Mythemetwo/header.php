<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php
	wp_head();
    ?>

</head>
<body>


<div id="wrap">

		<header id="header">
			<div class="container">
				<div class="row">
					<div class="col-xs-8 col-sm-6">
				
					<a class="logo" href="">
					<img src="" />
					</a>
					</div>

					<div class="col-sm-6 hidden-xs">
						<ul class="menu">
							<li class="current-menu-item">
						       <a>  <?php wp_nav_menu() ?> </a>
							</li>
						</ul>
					</div>
					<div class="col-xs-4 text-right visible-xs">
						<div class="mobile-menu-wrap">
							<i class="fa fa-search"></i>
							<i class="fa fa-bars menu-icon"></i>
					</div>
				</div>
			   </div>
              </div>
            </header>
		  

		<div class="mobile-search">
			<form id="searchform" class="searchform">
				<div>
					<label class="screen-reader-text">Sök efter:</label>
					<input type="text" />
					<input type="submit" value="Sök" />
				</div>
			</form>
		</div>

		<nav id="nav">
			<div class="container">
				<div class="row">
				  
					<div class="col-xs-8">
						<ul class="breadcrumbs">
							<li>Du är här: </li>
							<li>
							<?php
                          if ( function_exists('yoast_breadcrumb') ) {
                              yoast_breadcrumb( '<p id="breadcrumbs">','</p>' );
                             }
                             ?>

							</li>
						</ul>
					</div>

					
					       <?php
                               if(is_active_sidebar('footer-5')){
                               dynamic_sidebar('footer-5');
						  } ?>
						 
					
			

				</div>	
			</div>
		</nav>
	