
<?php
/* Template Name: Undersida Exempelsida 1 */
get_header(); 
?>


<main>
         <?php if(have_rows("title_exempel")):?>
				<?php while (have_rows("title_exempel")): the_row(); ?>
					<?php if(get_row_layout() == "hero_ex_1"): ?>
						<?php get_template_part("./sections/hero-ex1"); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>

		
			<section class="standard">
				<div class="container">
					<div class="row">
						<div class="col-xs-6">
                       <?php the_post_thumbnail(); ?>
						</div>
						<div class="col-xs-6">
                        <?php
                            if ( have_posts() ){

                             while ( have_posts() ){

                           the_post();
                            get_template_part('template-parts/content', 'page' );
    }
}
?>
						</div>
					</div>
                </div>
            </section>

<?php $randsimplu = get_field('rand_simplu'); ?>

			<section class="testimonial red">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 col-xs-offset-2">
							<h2><?php echo $randsimplu['text_stanga']; ?></h2>
						</div>
					<?php	$links =  get_sub_field('text_dreapta'); ?>
						<div class="col-xs-2 text-right">
							<a href="<?php echo $links['url']; ?>" class="btn btn-default"> Lorem Ipsum</a>
						</div>
					</div>
				</div>
            </section>
			
			<section class="slideshow" data-autoplay="5000" data-singleitem="false" data-items="2">
			<div class="Slideshow owl-carousel owl-theme">
				<?php if(have_rows("slides_demo")): ?>
					<?php while(have_rows("slides_demo")): the_row(); ?>
					<div class="slide" style="background-image: url('<?php the_sub_field('image_demo'); ?>');">
				   </div>
					<?php endwhile; ?>   
				<?php endif; ?>  
			</div> 
			</section>

			

        

<?php $titlusimplu = get_field('titlu_simplu'); ?>
			<section class="columns black text-center">
				<div class="container">
					<div class="row top">

						<div class="col-xs-12">
							<h2><?php echo $titlusimplu  ?></h2>
						</div>
					</div>

		<?php if(have_rows('repeater_exempel_one')): ?>
					<div class="row bottom">
						<?php while(have_rows('repeater_exempel_one')): the_row();
						 
				          $fot = get_sub_field('poza_ex');
				          $tit = get_sub_field('title_ex');
				          $con = get_sub_field('text_ex');
				     ?>

						<div class="col-xs-3">
						<?php if($fot):?>
								<?php echo $fot; ?>
							<?php endif; ?>

							<h3><?php echo $tit;?> </h3>
							<p><?php echo $con;?></p>
						</div>
					
				            <?php endwhile; ?>
			
				       </div>	

		<?php endif; ?>
	</div>
</section>
			


<?php $linie= get_field('linie_text'); ?>
			<section class="testimonial">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 col-xs-offset-3 text-center">
							<h2><?php echo $linie ?></h2>
						</div>
					</div>
				</div>
			</section>
			
			<section class="slideshow" data-autoplay="3000" data-singleitem="true">
	          <div class="Slideshowex2 owl-carousel owl-theme">
	             <?php if(have_rows("fem_slide")): ?>
                   <?php while(have_rows("fem_slide")): the_row();?>
			          <?php if(get_row_layout() == "foto_simple"):?>
				   <?php get_template_part("./sections/slide-foto"); ?>
			          <?php elseif (get_row_layout() == "logo_text"): ?>
				  <?php get_template_part("./sections/slide-logo-text"); ?>
				      <?php elseif (get_row_layout() == "image_text"): ?>
				  <?php get_template_part("./sections/slide-text-backgr"); ?>
				        <?php elseif (get_row_layout() == "slide_text_logo1"): ?>
				  <?php get_template_part("./sections/slide-text-logo"); ?>
				      <?php elseif (get_row_layout() == "foto_simple"): ?>
				  <?php get_template_part("./sections/slide-foto"); ?>
	          <?php endif; ?>
	    	<?php endwhile; ?>
	      <?php endif; ?>
	   </div>
	</section>  
				
				
				
				
			</section> 
			
			<?php $lastt= get_field('last_title_ex'); ?>	
			<section class="columns text-center">
				<div class="container">
					<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $lastt ?></h2>
						</div>
					</div>

					<?php if(have_rows('repeater_2')): ?>
					<div class="row bottom">
						<?php while(have_rows('repeater_2')): the_row();
						 
				          $fot2 = get_sub_field('imag2');
				          $tit2 = get_sub_field('title_2');
				          $con2 = get_sub_field('text_2');
				     ?>

						<div class="col-xs-6">
						<?php if($fot2):?>
								<?php echo $fot2; ?>
							<?php endif; ?>

							<h3><?php echo $tit2;?> </h3>
							<p><?php echo $con2;?></p>
						</div>
					
				            <?php endwhile; ?>
			
				       </div>	

		<?php endif; ?>
	</div>
</section>
				
				
</main>

					


<?php
get_footer();
?>