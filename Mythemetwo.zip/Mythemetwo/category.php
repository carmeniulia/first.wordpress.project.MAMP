

<?php
get_header();
?>



<main>
			<section>
				<div class="container">
					<div class="row">
						<div id="primary" class="col-xs-12 col-md-9">
							<h1><?php single_cat_title(); ?></h1>

<?php
if ( have_posts() ){

    while ( have_posts() ){

         the_post();
         get_template_part('template-parts/content', 'archive' );
    }
}
?>


<nav class="navigation pagination">
<?php
                the_posts_pagination([
                    "prev_text" => "Föregoende",
                    "next_text" => "Nästa"
				]);
		?>
							</nav>
						</div>
						<aside id="secondary" class="col-xs-12 col-md-3">
							<div id="sidebar">
								<ul>
									<li>
										<form id="searchform" class="searchform">
											<div>
												<label class="screen-reader-text">Sök efter:</label>
												<input type="text" />
												<input type="submit" value="Sök" />
											</div>
										</form>
									</li>
								</ul>
								<ul role="navigation">
									
									</li>
									<li>
										<h2>Arkiv</h2>
										<ul>
											<li>
												<?php  wp_get_archives(); ?> 
											</li>
										</ul>
									</li>
									<li class="categories">
										<h2>Kategorier</h2>
										<ul>
											<li class="cat-item">
										  <?php	the_category(); ?>
											</li>
											
										</ul>
									</li>
								</ul>
							</div>
						</aside>
					</div>
				</div>
			</section>
		</main>
			


<?php
get_footer();
?>
 




    

