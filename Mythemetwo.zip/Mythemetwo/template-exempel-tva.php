
<?php
/* Template Name: Undersida Exempelsida 2 */
get_header(); 
?>

<?php

$titlu2 = get_field('title_sida_two');

?>

<main>

        <?php if(have_rows("hero_exempelsida_2")):?>
				<?php while (have_rows("hero_exempelsida_2")): the_row(); ?>
					<?php if(get_row_layout() == "hero_ex2"): ?>
						<?php get_template_part("./sections/hero-ex2"); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>
			

	<?php  $title2 = get_field('title_2_puffar')?>
			<section class="columns black text-center">
				<div class="container">
					<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $title2;?></h2>
						</div>
					</div>


					<?php if(have_rows('section_2_puffar')): ?>
                       <div class="row bottom">
			
				<?php while(have_rows('section_2_puffar')): the_row();
				
				  $foto2p = get_sub_field('img_2_puff');
				  $titlu2p = get_sub_field('title_2_puff');
				  $continut2p = get_sub_field('text_2_puff');
				  ?>
                        <div class="col-xs-6">
							<?php if($foto2p):?>
								<?php echo $foto2p; ?>
							<?php endif; ?>

							<h3><?php echo $titlu2p;?> </h3>
							<p><?php echo $continut2p;?> </p>
						</div>
				            <?php endwhile; ?>
			
				       </div>	

                    <?php endif; ?>

				</div>
			</section>
				

			<?php   $title3 = get_field('title_3_puffar')?>
			<section class="columns red text-center">
				<div class="container">
					<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $title3;?></h2>
						</div>
					</div>

					
					<?php if(have_rows('section_3_puffar')): ?>
                       <div class="row bottom">
			
				<?php while(have_rows('section_3_puffar')): the_row();
				
				  $foto3p = get_sub_field('img_3_puff');
				  $titlu3p = get_sub_field('title_3_puff');
				  $continut3p = get_sub_field('text_3_puff');
				  ?>
                        <div class="col-xs-4">
							<?php if($foto3p):?>
								<?php echo $foto3p; ?>
							<?php endif; ?>

							<h3><?php echo $titlu3p;?> </h3>
							<p><?php echo $continut3p;?> </p>
						</div>
				            <?php endwhile; ?>
			
				       </div>	

                    <?php endif; ?>

				</div>
			</section>

			<?php   $title4 = get_field('title_4_puffar')?>
			<section class="columns text-center">
				<div class="container">
					<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $title4;?></h2>
						</div>
					</div>

					
					<?php if(have_rows('section_4_puffar')): ?>
                       <div class="row bottom">
			
				<?php while(have_rows('section_4_puffar')): the_row();
				
				  $foto4p = get_sub_field('img_4_puff');
				  $titlu4p = get_sub_field('title_4_puff');
				  $continut4p = get_sub_field('text_4_puff');
				  ?>
                        <div class="col-xs-3">
							<?php if($foto4p):?>
								<?php echo $foto4p; ?>
							<?php endif; ?>

							<h3><?php echo $titlu4p;?> </h3>
							<p><?php echo $continut4p;?> </p>
						</div>
				            <?php endwhile; ?>
			
				       </div>	

                    <?php endif; ?>

				</div>
			</section>
		
<section class="slideshow" data-autoplay="3000" data-singleitem="true">
	<div class="Slideshowex2 owl-carousel owl-theme">
	    <?php if(have_rows("slideshow_sidatva")): ?>
           <?php while(have_rows("slideshow_sidatva")): the_row();?>
			          <?php if(get_row_layout() == "slide_bild"):?>
				   <?php get_template_part("./sections/slide-ex2-1"); ?>
			          <?php elseif (get_row_layout() == "slide_tva"): ?>
				  <?php get_template_part("./sections/slide-ex2-2"); ?>
				      <?php elseif (get_row_layout() == "slide_tre"): ?>
				  <?php get_template_part("./sections/slide-ex2-3"); ?>
				      <?php elseif (get_row_layout() == "slide_bild"): ?>
				  <?php get_template_part("./sections/slide-ex2-1"); ?>
	          <?php endif; ?>
	    	<?php endwhile; ?>
	      <?php endif; ?>
	   </div>
	</section>  
				

            <section class="slideshow" data-autoplay="5000" data-singleitem="false" data-items="2">
			<div class="Slideshowabout owl-carousel owl-theme">
				<?php if(have_rows("slide_2")): ?>
					<?php while(have_rows("slide_2")): the_row(); ?>
					<div class="slide" style="background-image: url('<?php the_sub_field('imag_sf'); ?>');">
				   </div>
					<?php endwhile; ?>   
				<?php endif; ?>  
			</div> 
			</section>

		</main>




<?php
get_footer();
?>