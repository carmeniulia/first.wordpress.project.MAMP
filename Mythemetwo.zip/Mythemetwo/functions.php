<?php

function carmen_theme_support(){
    //add dynamic title support
add_theme_support('tittle-tag');
add_theme_support('custom-logo');
add_theme_support( 'post-thumbnails');
}

add_action('after_setup_theme','carmen_theme_support');

function carmen_menus(){

    $location = array(
        'primary' => "Menu",
        'footer'  => "Footer Menu"
    );

     register_nav_menus($location);


} 


add_action('init', 'carmen_menus');

add_image_size('smallest', 300,300, true);
add_image_size('largest', 800,800, true);
add_image_size('slider', 1200,700, true);

function carmen_register_styles(){
    $version = wp_get_theme()->get( 'Version' );
     wp_enqueue_style ('carmen-style', get_stylesheet_directory_uri() . "/style.css", array('carmen-bootstrap'), $version, 'all' );
     wp_enqueue_style ("owl", get_stylesheet_directory_uri() . "/assets/CSS/owl.carousel.min.css", $version, 'all');
     wp_enqueue_style ("owlTheme", get_stylesheet_directory_uri() . "/assets/CSS/owl.theme.default.min.css", $version, 'all');
     wp_enqueue_style ('carmen-bootstrap', get_stylesheet_directory_uri() . "/CSS/bootstrap.css", array(),  $version, 'all' );
     wp_enqueue_style ('carmen-font', get_template_directory_uri() . "/CSS/font-awesome.css", array(),  $version, 'all' );
    
    
}

add_action('wp_enqueue_scripts', 'carmen_register_styles');

if(function_exists('acf_add_options_page')){
    acf_add_options_page();
}

function carmen_register_scripts(){

wp_enqueue_script(
    "owlScript",
    get_template_directory_uri() . "/assets/js/owl.carousel.min.js",
    array("jquery"),
    false,
    true
);

wp_enqueue_script(
    "owl",
    get_template_directory_uri() . "/assets/js/scriptowl.js", '', 1, true
);

wp_enqueue_script(
    "owl2",
    get_template_directory_uri() . "/assets/js/scriptex2.js", '', 1, true
);

wp_enqueue_script(
    "owlabout",
    get_template_directory_uri() . "/assets/js/scriptabout.js", '', 1, true
);

wp_enqueue_script('carmen-jqueryjs', get_template_directory_uri() . "/javascript/jquery.js", array(), '1.0');
wp_enqueue_script('carmen-owl', get_template_directory_uri() . "/javascript/owl.carousel.js", array(), '1.0');
wp_enqueue_script('carmen-scriptjs', get_template_directory_uri() . "/javascript/script.js", array(), '1.0', true);

wp_enqueue_script('carmen-flex', get_template_directory_uri() . "/javascript/jquery.flexslider-min.js", '', 1, true);
wp_enqueue_script('carmen-flex');

wp_enqueue_script('carmen-scriptt', get_template_directory_uri() . "/javascript/scriptt.js", '', 1, true);
wp_enqueue_script('carmen-scriptt');


}

add_action('wp_enqueue_scripts', 'carmen_register_scripts');







?>

<?php
register_sidebar( array(
'name' => 'Footer Area 1',
'id' => 'footer-1',
'description' => 'Appears in the footer area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );

register_sidebar( array(
'name' => 'Footer Area 2',
'id' => 'footer-2',
'description' => 'Appears in the footer area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );

register_sidebar( array(
'name' => 'Footer Area 3',
'id' => 'footer-3',
'description' => 'Appears in the footer area',
'before_widget' => '<aside id="%1$s" class="widget %2$s">',
'after_widget' => '</aside>',
'before_title' => '<h3 class="widget-title">',
'after_title' => '</h3>',
) );

register_sidebar( array(
    'name' => 'Footer Area 4',
    'id' => 'footer-4',
    'description' => 'Appears in the footer area',
    'before_widget' => '<aside id="%1$s" class="widget %2$s">',
    'after_widget' => '</aside>',
    'before_title' => '<h3 class="widget-title">',
    'after_title' => '</h3>',
    ) );

 register_sidebar( array(
        'name' => 'Footer Area 5',
        'id' => 'footer-5',
        'description' => 'Appears in the header',
        'before_widget' => '<aside id="%1$s" class="widget %2$s">',
        'after_widget' => '</aside>',
        ) );
    

        ?>
 