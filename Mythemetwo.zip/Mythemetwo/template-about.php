<?php
/* Template Name: Template om oss */
get_header(); 
?>

<main>
           <section class="standard">
				<div class="container">
					<div class="row">
						<div class="col-xs-6">
                        <?php the_title( '<h1>', '</h1>' ); ?>
                        <?php
                            if ( have_posts() ){

                             while ( have_posts() ){

                           the_post();
                            get_template_part('template-parts/content', 'page' );
    }
}
?>
						</div>
						<div class="col-xs-6">
						 <?php the_post_thumbnail(); ?>  <br> <br> <br>
						
						</div>
					</div>
				</div>
            </section>
            </section>

    <?php $raw1 = get_field('first_raw') ?>

			<section class="testimonial black">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 col-xs-offset-2">
							<h2><?php echo $raw1['text_raw']; ?></h2>
						</div>
						<div class="col-xs-2 text-right">
							<a href="http://localhost:8888/labb2/kontakt/" class="btn btn-default"> <?php echo $raw1['button_1']; ?></a>
						</div>
					</div>
				</div>
			</section>
  
	

   <section class="slideshow" data-autoplay="5000" data-singleitem="false">
			<div class="Slideshowabout owl-carousel  owl-theme">
				<?php if(have_rows("slide_one")): ?>
					<?php while(have_rows("slide_one")): the_row(); ?>
					<div class="slide" style="background-image: url('<?php the_sub_field('imagi_ex'); ?>');">
				   </div>
					<?php endwhile; ?>   
				<?php endif; ?>  
			</div> 
			</section>


<?php $pen = get_field('simple_about') ?>
			<section class="columns red text-center">
				<div class="container">
					<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $pen ?></h2>
						</div>
					</div>
					
					<?php if(have_rows('repeater_team')): ?>
					<div class="row bottom">
					       <?php while(have_rows('repeater_team')): the_row(); 
						     $fotot = get_sub_field('image_team');
							 $titlut = get_sub_field('team_name');
							 $continutt = get_sub_field('team_content');
							 $linkt =  get_sub_field('team_link');
							 ?>
						
						<div class="col-xs-3">
							<?php if($fotot): ?>
							<img src="<?php echo $fotot ?>" alt="<?php echo $fotot['alt']; ?>" />
							<?php endif; ?>
							
							<h3><?php echo  $titlut ?></h3>
							<p> <?php echo  $continutt ?></p>
							 <?php if($linkt):?>
							
							<a href="<?php echo $linkt['url']; ?>" class="btn btn-default">Läs mer</a>
							<?php endif; ?>
						</div>
						<?php endwhile; ?>

					</div>

				  <?php endif; ?>
			   </div>
			</section>

			<?php $pentwo = get_field('simple_about_last') ?>
			<section class="columns text-center">
				<div class="container">
					<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $pentwo ?></h2>
						</div>
					</div>

					<?php if(have_rows('repeater_about')): ?>
					<div class="row bottom">

						   <?php while(have_rows('repeater_about')): the_row(); 
						     $fotop = get_sub_field('imag_penultim');
							 $titlup = get_sub_field('titlu_penultim');
							 $continutp = get_sub_field('content_penultim');
							 ?>
						
						<div class="col-xs-4">
							<?php if($fotop):?>
								<?php echo $fotop; ?>
							<?php endif; ?>

							<h3><?php echo $titlup;?> </h3>
							<p><?php echo $continutp;?> </p>
						</div>
				 <?php endwhile; ?>
			
				</div>	

          <?php endif; ?>
						
				</div>
			</section>
			
<?php $rawlast = get_field('last_raw') ?>	

			<section class="columns red text-center">
				<div class="container">
					<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $rawlast['titlu_last']; ?></h2>
						</div>
					</div>
					<div class="row bottom">
						<div class="col-xs-5 col-xs-offset-1">
							<blockquote>
								<p><?php echo $rawlast['stanga']; ?></p>							
							</blockquote>
						</div>
						<div class="col-xs-5">
							<blockquote>
								<p><p><?php echo $rawlast['dreapta']; ?></p></p>							
							</blockquote>
						</div>
					</div>
				</div>
			</section>
        </main>
        
<?php
get_footer();
?>