<?php
get_header();
?>

<?php

 $hero = get_field('hero');
 $testimonialred = get_field('testimonial_red');
?>
<main>
			<?php if(have_rows("hero_hem")):?>
				<?php while (have_rows("hero_hem")): the_row(); ?>
					<?php if(get_row_layout() == "hero_hem_one"): ?>
						<?php get_template_part("./sections/hero-section"); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>
		
			

			<section class="testimonial black">
				<div class="container">
					<div class="row">
						<div class="col-xs-6 col-xs-offset-3 text-center">
							<h2><?php echo $hero['text_center']; ?></h2>
						</div>
					</div>
				</div>
			</section>
			

<?php   $info = get_field('main_info')?>

			<section class="columns text-center">
				<div class="container">
					<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $info['title_main_info'];?> </h2>
						</div>
					</div>

					

      <?php if(have_rows('three_parts')): ?>
       <div class="row bottom">
			
				<?php while(have_rows('three_parts')): the_row();
				
				  $foto = get_sub_field('image_front');
				  $titlu = get_sub_field('title_front');
				  $continut = get_sub_field('content_front');
				  ?>
                        <div class="col-xs-4">
							<?php if($foto):?>
								<?php echo $foto; ?>
							<?php endif; ?>

							<h3><?php echo $titlu;?> </h3>
							<p><?php echo $continut;?> </p>
						</div>
				            <?php endwhile; ?>
			
				       </div>	

                    <?php endif; ?>

				</div>
			</section>

	  <!--  FLEXIBLE Content slideshow--> 
	  <section class="slideshow" data-autoplay="3000" data-singleitem="true"> 
	  <div class="Slideshowex2 owl-carousel owl-theme">
	    <?php if(have_rows("sections")): ?>
           <?php while(have_rows("sections")): the_row();?>
			          <?php if(get_row_layout() == "second_slide"):?>
				   <?php get_template_part("./sections/section-firstslidetwo"); ?>
			          <?php elseif (get_row_layout() == "first_slide"): ?>
				  <?php get_template_part("./sections/section-firstslide"); ?>
	          <?php endif; ?>
	    	<?php endwhile; ?>
	      <?php endif; ?>
	   </div>
	</section>  
	
	

			
<?php $last = get_field('front_last') ?>	

			<section class="columns text-center">
				<div class="container">
					<div class="row top">
						<div class="col-xs-12">
							<h2><?php echo $last['title_last'];?> </h2>
						</div>
					</div>

					<div class="row bottom">
						<div class="col-xs-5 col-xs-offset-1">
							<blockquote>
								<p><?php echo $last['content_l'];?></p>							
							</blockquote>
						</div>
						<div class="col-xs-5">
							<blockquote>
								<p><?php echo $last['content_r'];?></p>							
							</blockquote>
						</div>
					</div>
				</div>
			</section>
		</main>

<?php
get_footer();
?>
 
