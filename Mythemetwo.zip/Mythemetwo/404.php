<?php
get_header();
?>

<h1> Page Not Found </h1>

<?php
get_search_form();
?>
 

<?php
get_footer();
?>
 
