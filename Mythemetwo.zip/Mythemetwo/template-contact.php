
<?php
/* Template Name: Kontakt */
get_header(); 
?>
	
		
			
			<main>
			<?php if(have_rows("hero_k")):?>
				<?php while (have_rows("hero_k")): the_row(); ?>
					<?php if(get_row_layout() == "hero_kontakt"): ?>
						<?php get_template_part("./sections/hero-kontakt"); ?>
					<?php endif; ?>
				<?php endwhile; ?>
			<?php endif; ?>

			<section class="standard">
				<div class="container">
					<div class="row">
						
							<?php
                            if ( have_posts() ) { ?>
                       <div class="col-xs-6">
                            <?php while ( have_posts() ){

                           the_post();
                            get_template_part('template-parts/content', 'page' );
                           }
                         }
                      ?>
                      </div>
					</div>
				</div>
			</section>
		</main>
<?php 
get_footer();
?>